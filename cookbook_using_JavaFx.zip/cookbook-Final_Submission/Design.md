## Detailed Design
## Class Diagram

![class diagram](diagrams/ClassDiagramprojectCouse.png)


## Object Diagram
### add a new comment

![Sencond sequence diagram](diagrams/ObjectDiagram_project.png)


### Sequence Diagrams
### How to add a new comment

![First sequence diagram](diagrams/sequenceDiagramProjectCourse.png)
