# C

## Overall
You worked great and listened to the customer. A solid effort!

## Code
Fairly easy to follow, the beginning of an MVC pattern, but not completed. Mostly easy to understand code.

## Presentation
Could perhaps have been a bit better prepared, but okay and nothing bad, really.

Group grade: A
