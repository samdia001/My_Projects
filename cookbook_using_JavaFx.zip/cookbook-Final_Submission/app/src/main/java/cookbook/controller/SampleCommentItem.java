package cookbook.controller;

public class SampleCommentItem {
}
