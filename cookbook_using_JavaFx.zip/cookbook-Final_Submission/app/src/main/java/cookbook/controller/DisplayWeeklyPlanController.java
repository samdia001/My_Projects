package cookbook.controller;



import cookbook.model.WeeklyDinnerList;
import javafx.fxml.FXML;
import javafx.scene.control.TableView;

public class DisplayWeeklyPlanController {

    @FXML
    private TableView<WeeklyDinnerList> WeeklyDinnerListTable;

}
