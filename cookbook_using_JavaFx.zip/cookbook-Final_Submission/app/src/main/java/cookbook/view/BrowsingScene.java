package cookbook.view;

public class BrowsingScene {
}
